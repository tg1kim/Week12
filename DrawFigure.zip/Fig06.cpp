#include "Figure.h"

void DrawFigure(int n)
{
	for (int nY = 0; nY <= n; nY++) {
		for (int nX = -n; nX <= 0; nX++) {
			int nAX = Abs(nX), nAY = Abs(nY);
			putchar(nAY <= -nAX + n ? '*' : ' ');
		}
		putchar('\n');
	}
}
