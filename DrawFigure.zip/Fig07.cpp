#include "Figure.h"

void DrawFigure(int n)
{
	for (int nY = -n; nY <= 0; nY++) {
		for (int nX = -n; nX <= n; nX++) {
			int nAX = Abs(nX), nAY = Abs(nY);
			putchar(nAY <= -nAX + n ? '*' : ' ');
		}
		putchar('\n');
	}
}
