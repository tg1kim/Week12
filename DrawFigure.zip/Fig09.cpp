#include "Figure.h"

void DrawFigure(int n)
{
	for (int nY = -n; nY <= n; nY++) {
		for (int nX = 0; nX <= n; nX++) {
			int nAX = Abs(nX), nAY = Abs(nY);
			putchar(nAY <= -nAX + n ? '*' : ' ');
		}
		putchar('\n');
	}
}
