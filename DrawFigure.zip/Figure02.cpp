#include "Figure.h"

void DrawFigure(int n)
{
	PrintChars(n, '*', true);
	for (int i = 2; i < n; i++) {
		PrintChars(1);
		PrintChars(n - 2, ' ');
		PrintChars(1, '*', true);
	}
	if (n > 1)
		PrintChars(n, '*', true);
}
