#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 1; i <= n; i++) {
		PrintChars(n - i, ' ');
		PrintChars(i, '*', true);
	}
}
