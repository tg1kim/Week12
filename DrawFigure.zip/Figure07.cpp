#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 1; i <= n; i++) {
		PrintChars(n - i, ' ');
		PrintChars(2 * i - 1, '*', true);
	}
}
