#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 0; i < n; i++) {
		PrintChars(i, ' ');
		PrintChars(2 * (n - i) - 1, '*', true);
	}
}
