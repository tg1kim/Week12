#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 1; i <= n; i++)
		PrintChars(i, '*', true);
	for (int i = n - 1; i > 0; i--)
		PrintChars(i, '*', true);
}
