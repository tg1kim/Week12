#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 0; i < n; i++) {
		PrintChars(i, ' ');
		PrintChars(1, '*', true);
	}
}
