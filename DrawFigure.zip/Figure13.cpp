#include "Figure.h"

void DrawFigure(int n)
{
	for (int nY = 0; nY < n; nY++) {
		for (int nX = 0; nX < n; nX++)
			putchar(nY == nX || nY == -nX + n - 1 ? '*' : ' ');
		putchar('\n');
	}
}
