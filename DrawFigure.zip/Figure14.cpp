#include "Figure.h"

void DrawFigure(int n)
{
	for (int nY = 0; nY < n; nY++) {
		for (int nX = 0; nX < n; nX++) {
			int nDif = Abs(nY - nX), nSum = Abs(nX + nY - n + 1);
			putchar(nDif <= 1 || nSum <= 1 ? '*' : ' ');
		}
		putchar('\n');
	}
}
