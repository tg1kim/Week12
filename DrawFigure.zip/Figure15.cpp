#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 1; i < n; i++) {
		PrintChars(i, '*');
		PrintChars(2 * (n - i) - 1, ' ');
		PrintChars(i, '*', true);
	}
	PrintChars(2 * n - 1, '*', true);
	for (int i = n - 1; i > 0; i--) {
		PrintChars(i, '*');
		PrintChars(2 * (n - i) - 1, ' ');
		PrintChars(i, '*', true);
	}
}
