#include "Figure.h"

void DrawFigure(int n)
{
	for (int i = 0; i < n; i++) {
		PrintChars(i, ' ');
		PrintChars(2 * (n - i) - 1, '*', true);
	}
	for (int i = n - 2; i >= 0; i--) {
		PrintChars(i, ' ');
		PrintChars(2 * (n - i) - 1, '*', true);
	}
}
